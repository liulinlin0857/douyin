#!/bin/bash

echo "=== 抖音观众数据采集模块 - 构建脚本 ==="
echo "项目路径: /sdcard/Download/DouyinHook"
echo ""

# 检查是否在正确的目录
if [ ! -f "build.gradle" ]; then
    echo "错误: 请在DouyinHook项目根目录运行此脚本"
    exit 1
fi

# 检查Android SDK
if [ -z "$ANDROID_HOME" ]; then
    echo "警告: ANDROID_HOME环境变量未设置"
    echo "请确保已安装Android SDK"
fi

# 检查Java
if ! command -v java &> /dev/null; then
    echo "错误: 未找到Java，请安装JDK"
    exit 1
fi

echo "开始构建..."
echo ""

# 如果有gradlew，使用gradlew
if [ -f "gradlew" ]; then
    echo "使用Gradle Wrapper..."
    chmod +x gradlew
    ./gradlew assembleDebug
else
    echo "提示: 未找到gradlew，请使用Android Studio编译"
    echo ""
    echo "编译步骤:"
    echo "1. 安装Android Studio"
    echo "2. 打开项目: File -> Open -> 选择此目录"
    echo "3. 等待Gradle同步完成"
    echo "4. 编译: Build -> Build Bundle(s) / APK(s) -> Build APK(s)"
    echo "5. APK位置: app/build/outputs/apk/debug/app-debug.apk"
fi

echo ""
echo "=== 构建完成 ==="