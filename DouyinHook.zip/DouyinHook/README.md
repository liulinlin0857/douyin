# 抖音观众数据采集模块 (LSPosed)

## 简介
这是一个基于LSPosed框架的Xposed模块，用于采集抖音直播间观众数据。

## 功能特性
- 实时采集直播间观众列表
- 记录观众昵称、ID、等级等信息
- 自动保存数据到本地存储
- 支持JSON格式导出
- 低内存占用，稳定运行

## 系统要求
- Android 9.0+ (API 28+)
- 已安装LSPosed框架
- 已root设备

## 快速编译方法

### 方法一：GitHub Actions自动编译（推荐）
1. 将项目上传到GitHub仓库
2. GitHub Actions会自动编译APK
3. 在Actions页面下载编译好的APK

### 方法二：本地Android Studio编译
1. 将项目文件夹复制到电脑
2. 使用Android Studio打开项目
3. 等待Gradle同步完成
4. 点击Build -> Build Bundle(s) / APK(s) -> Build APK(s)
5. 生成的APK在 `app/build/outputs/apk/debug/` 目录

### 方法三：使用在线编译服务
1. 运行打包脚本：`python3 打包脚本.py`
2. 上传生成的ZIP文件到在线编译平台
3. 下载编译好的APK

## 安装步骤

### 1. 编译APK
使用上述任一方法编译APK

### 2. 安装模块
1. 将编译好的APK传输到手机
2. 安装APK到设备
3. 在LSPosed管理器中激活模块
4. 选择抖音应用作为作用域

### 3. 使用模块
1. 重启抖音应用
2. 进入任意直播间
3. 模块会自动采集观众数据
4. 数据保存在 `/sdcard/DouyinData/` 目录

## 数据文件说明

### 文件结构
```
/sdcard/DouyinData/
├── app_launch.log          # 应用启动记录
├── live_room.log           # 直播间进入/退出记录
├── viewers.log             # 观众数据日志
├── viewers_20240101_120000.json  # JSON格式观众数据
└── ...                     # 其他数据文件
```

### 数据格式
```json
[
  {
    "nickname": "用户昵称",
    "timestamp": 1704067200000
  }
]
```

## LSPosed兼容性
- 完全兼容LSPosed框架
- 支持LSPosed 1.8.6+
- 已添加xposed_init文件
- 已配置xposed.prop文件
- 作用域配置正确

## 注意事项
1. 模块仅用于学习和研究目的
2. 请勿用于商业用途或非法用途
3. 抖音版本更新可能影响模块功能
4. 数据采集频率受抖音UI更新频率限制

## 常见问题

### Q: 模块不工作怎么办？
A: 检查以下项目：
1. LSPosed管理器中模块是否激活
2. 作用域是否选择抖音
3. 是否重启抖音应用
4. 设备是否有存储权限

### Q: 数据保存在哪里？
A: 数据保存在 `/sdcard/DouyinData/` 目录

### Q: 如何清除数据？
A: 在模块主界面点击"清除所有数据"按钮

### Q: 如何在手机上编译？
A: 查看`手机编译指南.txt`文件

## 技术支持
如有问题，请检查：
1. 抖音版本兼容性
2. LSPosed框架版本
3. 设备root状态

## 版本历史
- v1.0: 初始版本，支持基本观众数据采集