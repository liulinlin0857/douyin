package com.example.douyinhook;

/**
 * 礼物数据类
 */
public class GiftData {
    private String userId;
    private String nickname;
    private String giftName;
    private int giftCount;
    private int giftPrice;
    private long timestamp;
    private String roomId;
    private String giftId;
    
    public GiftData() {
        this.timestamp = System.currentTimeMillis();
    }
    
    public GiftData(String nickname, String giftName, int giftCount) {
        this.nickname = nickname;
        this.giftName = giftName;
        this.giftCount = giftCount;
        this.timestamp = System.currentTimeMillis();
    }
    
    // Getters and Setters
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getNickname() {
        return nickname;
    }
    
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
    
    public String getGiftName() {
        return giftName;
    }
    
    public void setGiftName(String giftName) {
        this.giftName = giftName;
    }
    
    public int getGiftCount() {
        return giftCount;
    }
    
    public void setGiftCount(int giftCount) {
        this.giftCount = giftCount;
    }
    
    public int getGiftPrice() {
        return giftPrice;
    }
    
    public void setGiftPrice(int giftPrice) {
        this.giftPrice = giftPrice;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }
    
    public String getGiftId() {
        return giftId;
    }
    
    public void setGiftId(String giftId) {
        this.giftId = giftId;
    }
    
    @Override
    public String toString() {
        return "GiftData{" +
                "nickname='" + nickname + '\'' +
                ", giftName='" + giftName + '\'' +
                ", giftCount=" + giftCount +
                ", timestamp=" + timestamp +
                '}';
    }
}