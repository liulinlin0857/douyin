package com.example.douyinhook.utils;

import android.os.Environment;

import com.example.douyinhook.hooks.ViewerListHook.ViewerInfo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.robv.android.xposed.XposedBridge;

public class DataUtils {
    
    private static final String TAG = "DataUtils";
    private static final String DATA_DIR = "DouyinData";
    
    // 记录应用启动
    public static void logAppLaunch() {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        String log = "[" + timestamp + "] 抖音应用启动\n";
        appendToFile("app_launch.log", log);
    }
    
    // 记录直播间进入
    public static void logLiveRoomEntry(String roomId, String anchorName) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        String log = "[" + timestamp + "] 进入直播间: " + roomId + " 主播: " + anchorName + "\n";
        appendToFile("live_room.log", log);
    }
    
    // 记录直播间退出
    public static void logLiveRoomExit() {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        String log = "[" + timestamp + "] 退出直播间\n";
        appendToFile("live_room.log", log);
    }
    
    // 保存观众数据
    public static void saveViewerData(List<ViewerInfo> viewers) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(timestamp).append("] 观众数据:\n");
        
        for (ViewerInfo viewer : viewers) {
            sb.append("  昵称: ").append(viewer.nickname);
            if (viewer.userId != null) {
                sb.append(", ID: ").append(viewer.userId);
            }
            if (viewer.level > 0) {
                sb.append(", 等级: ").append(viewer.level);
            }
            sb.append("\n");
        }
        
        appendToFile("viewers.log", sb.toString());
        
        // 同时保存为JSON格式
        saveViewerDataAsJson(viewers);
    }
    
    // 保存为JSON格式
    private static void saveViewerDataAsJson(List<ViewerInfo> viewers) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String filename = "viewers_" + timestamp + ".json";
        
        StringBuilder json = new StringBuilder();
        json.append("[\n");
        
        for (int i = 0; i < viewers.size(); i++) {
            ViewerInfo viewer = viewers.get(i);
            json.append("  {\n");
            json.append("    \"nickname\": \"").append(viewer.nickname).append("\",\n");
            json.append("    \"timestamp\": ").append(viewer.timestamp).append("\n");
            json.append("  }");
            if (i < viewers.size() - 1) {
                json.append(",");
            }
            json.append("\n");
        }
        
        json.append("]");
        
        appendToFile(filename, json.toString());
    }
    
    // 追加到文件
    private static void appendToFile(String filename, String content) {
        try {
            File dataDir = new File(Environment.getExternalStorageDirectory(), DATA_DIR);
            if (!dataDir.exists()) {
                dataDir.mkdirs();
            }
            
            File file = new File(dataDir, filename);
            FileWriter writer = new FileWriter(file, true);
            writer.append(content);
            writer.flush();
            writer.close();
            
            XposedBridge.log(TAG + ": 数据已保存到: " + file.getAbsolutePath());
            
        } catch (IOException e) {
            XposedBridge.log(TAG + ": 保存数据失败: " + e.getMessage());
        }
    }
}