package com.example.douyinhook;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 简单的Toast测试Hook
 * 用于确认模块是否正常加载
 */
public class ToastTestHook implements IXposedHookLoadPackage {
    
    private static final String TAG = "ToastTest";
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // 只处理抖音应用
        if (!lpparam.packageName.equals("com.ss.android.ugc.aweme")) {
            return;
        }
        
        XposedBridge.log(TAG + ": 模块已加载到抖音应用！");
        XposedBridge.log(TAG + ": 包名: " + lpparam.packageName);
        XposedBridge.log(TAG + ": 进程名: " + lpparam.processName);
        
        // Hook Activity onCreate 方法
        XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Activity activity = (Activity) param.thisObject;
                String activityName = activity.getClass().getName();
                
                XposedBridge.log(TAG + ": Activity onCreate: " + activityName);
                
                // 只在主Activity显示Toast
                if (activityName.contains("MainActivity") || 
                    activityName.contains("SplashActivity") ||
                    activityName.contains("HomeActivity")) {
                    
                    XposedBridge.log(TAG + ": 在主Activity显示Toast");
                    
                    // 显示Toast
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(activity, 
                                "抖音Hook模块已加载！", 
                                Toast.LENGTH_LONG).show();
                            
                            XposedBridge.log(TAG + ": Toast已显示");
                        }
                    });
                }
            }
        });
        
        XposedBridge.log(TAG + ": Hook已设置完成，等待Activity创建...");
    }
}