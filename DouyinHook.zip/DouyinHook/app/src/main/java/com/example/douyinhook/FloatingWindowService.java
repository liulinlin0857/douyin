package com.example.douyinhook;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.robv.android.xposed.XposedBridge;

/**
 * 悬浮窗服务
 */
public class FloatingWindowService extends Service {
    
    private static final String TAG = "FloatingWindow";
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private View floatingView;
    private TextView danmakuTextView;
    private TextView giftTextView;
    private ScrollView scrollView;
    private LinearLayout contentLayout;
    
    private boolean isShowing = false;
    private int lastDanmakuCount = 0;
    private int lastGiftCount = 0;
    
    // 日志文件路径
    private static final String LOG_FILE_PATH = "/sdcard/DouyinHook_logs.txt";
    
    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        writeLog("FloatingWindowService onCreate 开始");
        createFloatingWindow();
        startUpdateThread();
        writeLog("FloatingWindowService onCreate 完成");
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        writeLog("FloatingWindowService onStartCommand");
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        writeLog("FloatingWindowService onBind");
        return null;
    }
    
    /**
     * 创建悬浮窗
     */
    private void createFloatingWindow() {
        writeLog("createFloatingWindow 开始");
        
        // 创建悬浮窗布局
        createFloatingView();
        
        // 设置悬浮窗参数
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            );
        } else {
            layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            );
        }
        
        // 设置悬浮窗位置
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = 0;
        layoutParams.y = 100;
        
        // 添加悬浮窗到窗口管理器
        try {
            windowManager.addView(floatingView, layoutParams);
            isShowing = true;
            writeLog("悬浮窗添加成功");
        } catch (Exception e) {
            writeLog("悬浮窗添加失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * 创建悬浮窗视图
     */
    private void createFloatingView() {
        writeLog("createFloatingView 开始");
        
        // 创建根布局
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(0x88000000); // 半透明黑色背景
        rootLayout.setPadding(16, 16, 16, 16);
        
        // 标题
        TextView titleTextView = new TextView(this);
        titleTextView.setText("抖音直播数据");
        titleTextView.setTextColor(0xFFFFFFFF);
        titleTextView.setTextSize(16);
        titleTextView.setGravity(Gravity.CENTER);
        rootLayout.addView(titleTextView);
        
        // 分隔线
        View divider = new View(this);
        divider.setBackgroundColor(0x44FFFFFF);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 2));
        rootLayout.addView(divider);
        
        // 弹幕区域
        TextView danmakuTitle = new TextView(this);
        danmakuTitle.setText("【弹幕】");
        danmakuTitle.setTextColor(0xFFFFD700); // 金色
        danmakuTitle.setTextSize(14);
        rootLayout.addView(danmakuTitle);
        
        danmakuTextView = new TextView(this);
        danmakuTextView.setTextColor(0xFFFFFFFF);
        danmakuTextView.setTextSize(12);
        danmakuTextView.setMaxLines(10);
        rootLayout.addView(danmakuTextView);
        
        // 礼物区域
        TextView giftTitle = new TextView(this);
        giftTitle.setText("【礼物】");
        giftTitle.setTextColor(0xFFFF69B4); // 粉色
        giftTitle.setTextSize(14);
        rootLayout.addView(giftTitle);
        
        giftTextView = new TextView(this);
        giftTextView.setTextColor(0xFFFFFFFF);
        giftTextView.setTextSize(12);
        giftTextView.setMaxLines(10);
        rootLayout.addView(giftTextView);
        
        // 滚动视图
        scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 400));
        scrollView.addView(rootLayout);
        
        floatingView = scrollView;
        
        // 设置触摸监听器，支持拖拽
        setupTouchListener();
        
        writeLog("createFloatingView 完成");
    }
    
    /**
     * 设置触摸监听器
     */
    private void setupTouchListener() {
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = layoutParams.x;
                        initialY = layoutParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                        
                    case MotionEvent.ACTION_MOVE:
                        layoutParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                        layoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, layoutParams);
                        return true;
                }
                return false;
            }
        });
    }
    
    /**
     * 启动更新线程
     */
    private void startUpdateThread() {
        writeLog("startUpdateThread 开始");
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                writeLog("更新线程已启动");
                while (isShowing) {
                    try {
                        Thread.sleep(1000); // 每秒更新一次
                        updateFloatingWindow();
                    } catch (InterruptedException e) {
                        writeLog("更新线程中断: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
                writeLog("更新线程已停止");
            }
        }).start();
        
        writeLog("startUpdateThread 完成");
    }
    
    /**
     * 更新悬浮窗内容
     */
    private void updateFloatingWindow() {
        if (!isShowing) return;
        
        // 获取弹幕数据
        List<DanmakuData> danmakuList = DanmakuHook.getDanmakuList();
        int currentDanmakuCount = danmakuList.size();
        
        // 获取礼物数据
        List<GiftData> giftList = GiftHook.getGiftList();
        int currentGiftCount = giftList.size();
        
        // 如果有新数据，更新UI
        if (currentDanmakuCount != lastDanmakuCount || currentGiftCount != lastGiftCount) {
            lastDanmakuCount = currentDanmakuCount;
            lastGiftCount = currentGiftCount;
            
            writeLog("数据更新: 弹幕" + currentDanmakuCount + "条, 礼物" + currentGiftCount + "条");
            
            // 在主线程更新UI
            floatingView.post(new Runnable() {
                @Override
                public void run() {
                    updateDanmakuDisplay();
                    updateGiftDisplay();
                }
            });
        }
    }
    
    /**
     * 更新弹幕显示
     */
    private void updateDanmakuDisplay() {
        List<DanmakuData> danmakuList = DanmakuHook.getDanmakuList();
        StringBuilder sb = new StringBuilder();
        
        // 显示最近的弹幕
        int startIndex = Math.max(0, danmakuList.size() - 10);
        for (int i = startIndex; i < danmakuList.size(); i++) {
            DanmakuData danmaku = danmakuList.get(i);
            sb.append(danmaku.getNickname()).append(": ").append(danmaku.getContent()).append("\n");
        }
        
        if (sb.length() == 0) {
            sb.append("暂无弹幕...");
        }
        
        danmakuTextView.setText(sb.toString());
    }
    
    /**
     * 更新礼物显示
     */
    private void updateGiftDisplay() {
        List<GiftData> giftList = GiftHook.getGiftList();
        StringBuilder sb = new StringBuilder();
        
        // 显示最近的礼物
        int startIndex = Math.max(0, giftList.size() - 10);
        for (int i = startIndex; i < giftList.size(); i++) {
            GiftData gift = giftList.get(i);
            sb.append(gift.getNickname()).append(" 送出 ").append(gift.getGiftName()).append(" x").append(gift.getGiftCount()).append("\n");
        }
        
        if (sb.length() == 0) {
            sb.append("暂无礼物...");
        }
        
        giftTextView.setText(sb.toString());
    }
    
    /**
     * 显示悬浮窗
     */
    public void showFloatingWindow() {
        writeLog("showFloatingWindow 调用");
        if (!isShowing) {
            createFloatingWindow();
        }
    }
    
    /**
     * 隐藏悬浮窗
     */
    public void hideFloatingWindow() {
        writeLog("hideFloatingWindow 调用");
        if (isShowing) {
            try {
                windowManager.removeView(floatingView);
                isShowing = false;
                writeLog("悬浮窗已隐藏");
            } catch (Exception e) {
                writeLog("隐藏悬浮窗失败: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        writeLog("FloatingWindowService onDestroy");
        hideFloatingWindow();
    }
    
    /**
     * 写入日志到文件
     */
    private void writeLog(String message) {
        try {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            String logMessage = timestamp + " - " + message + "\n";
            
            File logFile = new File(LOG_FILE_PATH);
            FileOutputStream fos = new FileOutputStream(logFile, true);
            fos.write(logMessage.getBytes());
            fos.close();
            
            // 同时输出到Xposed日志
            XposedBridge.log(TAG + ": " + message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}