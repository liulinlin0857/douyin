package com.example.application600;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class SimpleTestHook implements IXposedHookLoadPackage {
    
    private static final String TAG = "SimpleTest";
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // 记录所有包的加载
        XposedBridge.log(TAG + ": 包已加载: " + lpparam.packageName);
        
        // 只处理抖音应用
        if (lpparam.packageName.equals("com.ss.android.ugc.aweme")) {
            XposedBridge.log(TAG + ": 检测到抖音应用！");
            XposedBridge.log(TAG + ": 模块正在工作！");
            XposedBridge.log(TAG + ": 包名: " + lpparam.packageName);
            XposedBridge.log(TAG + ": 进程名: " + lpparam.processName);
            
            // 发送一个简单的Toast提示（需要主线程）
            // 注意：这可能不会显示，但可以测试模块是否工作
            XposedBridge.log(TAG + ": 如果看到这条日志，说明模块已成功加载！");
        }
    }
}