package com.example.application600;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
/**
 * 礼物抓取Hook类
 */
public class GiftHook {
    
    private static final String TAG = "GiftHook";
    private static List<GiftData> giftList = new ArrayList<>();
    
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        XposedBridge.log(TAG + ": 初始化礼物抓取Hook");
        
        // 尝试Hook礼物数据接收
        hookGiftReceiver(lpparam);
        
        // 尝试Hook礼物数据解析
        hookGiftParser(lpparam);
        
        // 尝试Hook礼物显示
        hookGiftDisplay(lpparam);
    }
    
    /**
     * Hook礼物数据接收
     */
    private static void hookGiftReceiver(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook礼物数据接收
            XposedBridge.log(TAG + ": 尝试Hook礼物数据接收");
            
            // 尝试查找礼物相关类
            String[] possibleGiftClasses = {
                "com.ss.android.ugc.aweme.live.model.Gift",
                "com.ss.android.ugc.aweme.live.model.GiftMessage",
                "com.ss.android.ugc.aweme.live.model.GiftData",
                "com.ss.android.ugc.aweme.live.parser.GiftParser"
            };
            
            for (String className : possibleGiftClasses) {
                try {
                    Class<?> giftClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    XposedBridge.log(TAG + ": 找到礼物类: " + className);
                    
                    // Hook礼物相关方法
                    hookGiftMethods(giftClass, lpparam);
                    break;
                    
                } catch (Throwable e) {
                    // 继续尝试下一个
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook礼物数据接收失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook礼物类方法
     */
    private static void hookGiftMethods(Class<?> giftClass, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Method[] methods = giftClass.getDeclaredMethods();
            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.contains("receive") || 
                    methodName.contains("handle") ||
                    methodName.contains("parse") ||
                    methodName.contains("gift")) {
                    
                    XposedBridge.log(TAG + ": 找到礼物方法: " + methodName);
                    
                    // Hook该方法
                    XposedHelpers.findAndHookMethod(giftClass, methodName, 
                        method.getParameterTypes(), new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log(TAG + ": 礼物方法被调用: " + methodName);
                                
                                // 尝试解析礼物数据
                                Object result = param.getResult();
                                if (result != null) {
                                    parseGiftFromResult(result);
                                }
                            }
                        });
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook礼物方法失败: " + e.getMessage());
        }
    }
    
    /**
     * 解析礼物数据
     */
    private static void parseGiftFromResult(Object result) {
        try {
            XposedBridge.log(TAG + ": 尝试解析礼物数据: " + result.getClass().getName());
            
            // 检查是否是礼物对象
            if (result.getClass().getName().contains("Gift") || 
                result.getClass().getName().contains("礼物")) {
                
                // 尝试提取礼物信息
                GiftData gift = new GiftData();
                
                // 尝试获取昵称
                try {
                    Object nickname = XposedHelpers.getObjectField(result, "nickname");
                    if (nickname != null) {
                        gift.setNickname(nickname.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 尝试获取礼物名称
                try {
                    Object giftName = XposedHelpers.getObjectField(result, "giftName");
                    if (giftName != null) {
                        gift.setGiftName(giftName.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 尝试获取礼物数量
                try {
                    Object giftCount = XposedHelpers.getObjectField(result, "giftCount");
                    if (giftCount != null) {
                        gift.setGiftCount((Integer) giftCount);
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 如果成功提取到数据，添加到列表
                if (gift.getNickname() != null && gift.getGiftName() != null) {
                    giftList.add(gift);
                    XposedBridge.log(TAG + ": 成功提取礼物: " + gift.toString());
                    
                    // 通知悬浮窗更新
                    notifyFloatingWindowUpdate();
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 解析礼物数据失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook礼物数据解析
     */
    private static void hookGiftParser(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook礼物数据解析类
            XposedBridge.log(TAG + ": 尝试Hook礼物数据解析");
            
            // 尝试查找礼物解析相关类
            String[] possibleParserClasses = {
                "com.ss.android.ugc.aweme.live.parser.GiftParser",
                "com.ss.android.ugc.aweme.live.parser.MessageParser",
                "com.ss.android.ugc.aweme.live.parser.DataParser"
            };
            
            for (String className : possibleParserClasses) {
                try {
                    Class<?> parserClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    XposedBridge.log(TAG + ": 找到解析类: " + className);
                    
                    // Hook解析方法
                    hookParserMethods(parserClass, lpparam);
                    break;
                    
                } catch (Throwable e) {
                    // 继续尝试下一个
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook礼物数据解析失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook解析类方法
     */
    private static void hookParserMethods(Class<?> parserClass, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Method[] methods = parserClass.getDeclaredMethods();
            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.contains("parse") || 
                    methodName.contains("decode") ||
                    methodName.contains("convert") ||
                    methodName.contains("gift")) {
                    
                    XposedBridge.log(TAG + ": 找到解析方法: " + methodName);
                    
                    // Hook该方法
                    XposedHelpers.findAndHookMethod(parserClass, methodName, 
                        method.getParameterTypes(), new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log(TAG + ": 解析方法被调用: " + methodName);
                                
                                // 尝试提取礼物数据
                                Object result = param.getResult();
                                if (result != null) {
                                    extractGiftFromResult(result);
                                }
                            }
                        });
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook解析方法失败: " + e.getMessage());
        }
    }
    
    /**
     * 从解析结果中提取礼物
     */
    private static void extractGiftFromResult(Object result) {
        try {
            XposedBridge.log(TAG + ": 尝试从结果中提取礼物: " + result.getClass().getName());
            
            // 检查是否是礼物对象
            if (result.getClass().getName().contains("Gift") || 
                result.getClass().getName().contains("礼物")) {
                
                // 尝试提取礼物信息
                GiftData gift = new GiftData();
                
                // 尝试获取昵称
                try {
                    Object nickname = XposedHelpers.getObjectField(result, "nickname");
                    if (nickname != null) {
                        gift.setNickname(nickname.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 尝试获取礼物名称
                try {
                    Object giftName = XposedHelpers.getObjectField(result, "giftName");
                    if (giftName != null) {
                        gift.setGiftName(giftName.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 尝试获取礼物数量
                try {
                    Object giftCount = XposedHelpers.getObjectField(result, "giftCount");
                    if (giftCount != null) {
                        gift.setGiftCount((Integer) giftCount);
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 如果成功提取到数据，添加到列表
                if (gift.getNickname() != null && gift.getGiftName() != null) {
                    giftList.add(gift);
                    XposedBridge.log(TAG + ": 成功提取礼物: " + gift.toString());
                    
                    // 通知悬浮窗更新
                    notifyFloatingWindowUpdate();
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 提取礼物失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook礼物显示
     */
    private static void hookGiftDisplay(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook礼物显示相关视图
            XposedBridge.log(TAG + ": 尝试Hook礼物显示");
            
            // 尝试查找礼物显示相关类
            String[] possibleDisplayClasses = {
                "com.ss.android.ugc.aweme.live.widget.GiftView",
                "com.ss.android.ugc.aweme.live.widget.GiftContainer",
                "com.ss.android.ugc.aweme.live.widget.GiftRecyclerView",
                "com.ss.android.ugc.aweme.live.widget.LiveGiftView"
            };
            
            for (String className : possibleDisplayClasses) {
                try {
                    Class<?> displayClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    XposedBridge.log(TAG + ": 找到显示类: " + className);
                    
                    // Hook显示方法
                    hookDisplayMethods(displayClass, lpparam);
                    break;
                    
                } catch (Throwable e) {
                    // 继续尝试下一个
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook礼物显示失败: " + e.getMessage());
        }
    }
    
    /**
     * Hook显示类方法
     */
    private static void hookDisplayMethods(Class<?> displayClass, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Method[] methods = displayClass.getDeclaredMethods();
            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.contains("addGift") || 
                    methodName.contains("showGift") ||
                    methodName.contains("display") ||
                    methodName.contains("onDraw")) {
                    
                    XposedBridge.log(TAG + ": 找到显示方法: " + methodName);
                    
                    // Hook该方法
                    XposedHelpers.findAndHookMethod(displayClass, methodName, 
                        method.getParameterTypes(), new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log(TAG + ": 显示方法被调用: " + methodName);
                                
                                // 尝试从参数中提取礼物数据
                                Object[] args = param.args;
                                if (args != null && args.length > 0) {
                                    for (Object arg : args) {
                                        if (arg != null) {
                                            extractGiftFromDisplayArgs(arg);
                                        }
                                    }
                                }
                            }
                        });
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook显示方法失败: " + e.getMessage());
        }
    }
    
    /**
     * 从显示参数中提取礼物
     */
    private static void extractGiftFromDisplayArgs(Object arg) {
        try {
            XposedBridge.log(TAG + ": 尝试从显示参数中提取礼物: " + arg.getClass().getName());
            
            // 检查是否是礼物对象
            if (arg.getClass().getName().contains("Gift") || 
                arg.getClass().getName().contains("礼物")) {
                
                // 尝试提取礼物信息
                GiftData gift = new GiftData();
                
                // 尝试获取昵称
                try {
                    Object nickname = XposedHelpers.getObjectField(arg, "nickname");
                    if (nickname != null) {
                        gift.setNickname(nickname.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 尝试获取礼物名称
                try {
                    Object giftName = XposedHelpers.getObjectField(arg, "giftName");
                    if (giftName != null) {
                        gift.setGiftName(giftName.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 尝试获取礼物数量
                try {
                    Object giftCount = XposedHelpers.getObjectField(arg, "giftCount");
                    if (giftCount != null) {
                        gift.setGiftCount((Integer) giftCount);
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                }
                
                // 如果成功提取到数据，添加到列表
                if (gift.getNickname() != null && gift.getGiftName() != null) {
                    giftList.add(gift);
                    XposedBridge.log(TAG + ": 成功提取礼物: " + gift.toString());
                    
                    // 通知悬浮窗更新
                    notifyFloatingWindowUpdate();
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 从显示参数提取礼物失败: " + e.getMessage());
        }
    }
    
    /**
     * 通知悬浮窗更新
     */
    private static void notifyFloatingWindowUpdate() {
        // 这里需要与悬浮窗服务通信
        // 可以通过广播、接口或静态变量等方式
        XposedBridge.log(TAG + ": 通知悬浮窗更新，当前礼物数量: " + giftList.size());
        
        // 简单实现：直接打印到日志
        for (GiftData gift : giftList) {
            XposedBridge.log(TAG + ": 礼物 - " + gift.getNickname() + " 送出 " + gift.getGiftName() + " x" + gift.getGiftCount());
        }
    }
    
    /**
     * 获取礼物列表
     */
    public static List<GiftData> getGiftList() {
        return giftList;
    }
    
    /**
     * 清空礼物列表
     */
    public static void clearGiftList() {
        giftList.clear();
    }
}