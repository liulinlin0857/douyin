package com.example.douyinhook;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
/**
 * 弹幕抓取Hook类
 */
public class DanmakuHook {

    private static final String TAG = "DanmakuHook";
    private static List<DanmakuData> danmakuList = new ArrayList<>();
    private static final String LOG_FILE_PATH = "/sdcard/DanmakuHook_logs.txt";

    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        writeLog("初始化弹幕抓取Hook");

        // 尝试Hook弹幕数据接收
        hookDanmakuReceiver(lpparam);

        // 尝试Hook弹幕数据解析
        hookDanmakuParser(lpparam);

        // 尝试Hook弹幕显示
        hookDanmakuDisplay(lpparam);

        writeLog("弹幕抓取Hook初始化完成");
    }

    /**
     * Hook弹幕数据接收
     */
    private static void hookDanmakuReceiver(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook WebSocket数据接收
            // 抖音可能使用WebSocket接收实时弹幕
            writeLog("尝试Hook弹幕数据接收");

            // 尝试查找WebSocket相关类
            String[] possibleWebSocketClasses = {
                "com.ss.android.ugc.aweme.live.websocket.WebSocketClient",
                "com.ss.android.ugc.aweme.live.websocket.WebSocket",
                "com.ss.android.ugc.aweme.live.network.WebSocketManager",
                "com.ss.android.ugc.aweme.live.websocket.DouyinWebSocket"
            };

            for (String className : possibleWebSocketClasses) {
                try {
                    Class<?> wsClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    writeLog("找到WebSocket类: " + className);

                    // Hook消息接收方法
                    hookWebSocketMethods(wsClass, lpparam);
                    break;

                } catch (Throwable e) {
                    // 继续尝试下一个
                    writeLog("未找到WebSocket类: " + className);
                }
            }

        } catch (Throwable e) {
            writeLog("Hook弹幕数据接收失败: " + e.getMessage());
        }
    }

    /**
     * Hook WebSocket方法
     */
    private static void hookWebSocketMethods(Class<?> wsClass, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            writeLog("开始Hook WebSocket方法");

            // 尝试Hook消息接收方法
            Method[] methods = wsClass.getDeclaredMethods();
            writeLog("找到WebSocket方法数量: " + methods.length);

            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.contains("onMessage") || 
                    methodName.contains("handleMessage") ||
                    methodName.contains("receive") ||
                    methodName.contains("data")) {

                    writeLog("找到WebSocket方法: " + methodName);

                    // Hook该方法
                    XposedHelpers.findAndHookMethod(wsClass, methodName, 
                        method.getParameterTypes(), new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                writeLog("WebSocket方法被调用: " + methodName);

                                // 尝试解析弹幕数据
                                Object result = param.getResult();
                                if (result != null) {
                                    parseDanmakuFromWebSocket(result);
                                }
                            }
                        });
                }
            }

            writeLog("WebSocket方法Hook完成");

        } catch (Throwable e) {
            writeLog("Hook WebSocket方法失败: " + e.getMessage());
        }
    }

    /**
     * 解析WebSocket中的弹幕数据
     */
    private static void parseDanmakuFromWebSocket(Object data) {
        try {
            // 尝试从数据中提取弹幕信息
            // 这里需要根据实际的数据格式进行解析
            writeLog("尝试解析WebSocket数据: " + data.getClass().getName());

            // 如果是字符串，尝试解析JSON
            if (data instanceof String) {
                String jsonData = (String) data;
                writeLog("WebSocket数据长度: " + jsonData.length());

                if (jsonData.contains("danmaku") || jsonData.contains("弹幕")) {
                    writeLog("检测到弹幕数据");
                    // 解析JSON并创建DanmakuData对象
                } else {
                    writeLog("WebSocket数据不包含弹幕信息");
                }
            }

        } catch (Throwable e) {
            writeLog("解析WebSocket数据失败: " + e.getMessage());
        }
    }

    /**
     * Hook弹幕数据解析
     */
    private static void hookDanmakuParser(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook弹幕数据解析类
            writeLog("尝试Hook弹幕数据解析");

            // 尝试查找弹幕解析相关类
            String[] possibleParserClasses = {
                "com.ss.android.ugc.aweme.live.parser.DanmakuParser",
                "com.ss.android.ugc.aweme.live.parser.MessageParser",
                "com.ss.android.ugc.aweme.live.parser.DataParser",
                "com.ss.android.ugc.aweme.live.model.Danmaku"
            };

            for (String className : possibleParserClasses) {
                try {
                    Class<?> parserClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    writeLog("找到解析类: " + className);

                    // Hook解析方法
                    hookParserMethods(parserClass, lpparam);
                    break;

                } catch (Throwable e) {
                    // 继续尝试下一个
                    writeLog("未找到解析类: " + className);
                }
            }

        } catch (Throwable e) {
            writeLog("Hook弹幕数据解析失败: " + e.getMessage());
        }
    }

    /**
     * Hook解析类方法
     */
    private static void hookParserMethods(Class<?> parserClass, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            writeLog("开始Hook解析类方法");

            Method[] methods = parserClass.getDeclaredMethods();
            writeLog("找到解析类方法数量: " + methods.length);

            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.contains("parse") || 
                    methodName.contains("decode") ||
                    methodName.contains("convert") ||
                    methodName.contains("handle")) {

                    writeLog("找到解析方法: " + methodName);

                    // Hook该方法
                    XposedHelpers.findAndHookMethod(parserClass, methodName, 
                        method.getParameterTypes(), new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                writeLog("解析方法被调用: " + methodName);

                                // 尝试提取弹幕数据
                                Object result = param.getResult();
                                if (result != null) {
                                    extractDanmakuFromResult(result);
                                }
                            }
                        });
                }
            }

            writeLog("解析类方法Hook完成");

        } catch (Throwable e) {
            writeLog("Hook解析方法失败: " + e.getMessage());
        }
    }

    /**
     * 从解析结果中提取弹幕
     */
    private static void extractDanmakuFromResult(Object result) {
        try {
            writeLog("尝试从结果中提取弹幕: " + result.getClass().getName());

            // 检查是否是弹幕对象
            if (result.getClass().getName().contains("Danmaku") || 
                result.getClass().getName().contains("弹幕")) {

                writeLog("检测到弹幕对象");

                // 尝试提取弹幕信息
                DanmakuData danmaku = new DanmakuData();

                // 尝试获取昵称
                try {
                    Object nickname = XposedHelpers.getObjectField(result, "nickname");
                    if (nickname != null) {
                        danmaku.setNickname(nickname.toString());
                        writeLog("获取到昵称: " + nickname.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                    writeLog("获取昵称失败: " + e.getMessage());
                }

                // 尝试获取内容
                try {
                    Object content = XposedHelpers.getObjectField(result, "content");
                    if (content != null) {
                        danmaku.setContent(content.toString());
                        writeLog("获取到内容: " + content.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                    writeLog("获取内容失败: " + e.getMessage());
                }

                // 如果成功提取到数据，添加到列表
                if (danmaku.getNickname() != null && danmaku.getContent() != null) {
                    danmakuList.add(danmaku);
                    writeLog("成功提取弹幕: " + danmaku.toString());

                    // 通知悬浮窗更新
                    notifyFloatingWindowUpdate();
                } else {
                    writeLog("未能完整提取弹幕数据");
                }
            }

        } catch (Throwable e) {
            writeLog("提取弹幕失败: " + e.getMessage());
        }
    }

    /**
     * Hook弹幕显示
     */
    private static void hookDanmakuDisplay(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook弹幕显示相关视图
            writeLog("尝试Hook弹幕显示");

            // 尝试查找弹幕显示相关类
            String[] possibleDisplayClasses = {
                "com.ss.android.ugc.aweme.live.widget.DanmakuView",
                "com.ss.android.ugc.aweme.live.widget.DanmakuContainer",
                "com.ss.android.ugc.aweme.live.widget.DanmakuRecyclerView",
                "com.ss.android.ugc.aweme.live.widget.LiveDanmakuView"
            };

            for (String className : possibleDisplayClasses) {
                try {
                    Class<?> displayClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    writeLog("找到显示类: " + className);

                    // Hook显示方法
                    hookDisplayMethods(displayClass, lpparam);
                    break;

                } catch (Throwable e) {
                    // 继续尝试下一个
                    writeLog("未找到显示类: " + className);
                }
            }

        } catch (Throwable e) {
            writeLog("Hook弹幕显示失败: " + e.getMessage());
        }
    }

    /**
     * Hook显示类方法
     */
    private static void hookDisplayMethods(Class<?> displayClass, XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            writeLog("开始Hook显示类方法");

            Method[] methods = displayClass.getDeclaredMethods();
            writeLog("找到显示类方法数量: " + methods.length);

            for (Method method : methods) {
                String methodName = method.getName();
                if (methodName.contains("addDanmaku") || 
                    methodName.contains("showDanmaku") ||
                    methodName.contains("display") ||
                    methodName.contains("onDraw")) {

                    writeLog("找到显示方法: " + methodName);

                    // Hook该方法
                    XposedHelpers.findAndHookMethod(displayClass, methodName, 
                        method.getParameterTypes(), new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                writeLog("显示方法被调用: " + methodName);

                                // 尝试从参数中提取弹幕数据
                                Object[] args = param.args;
                                if (args != null && args.length > 0) {
                                    for (Object arg : args) {
                                        if (arg != null) {
                                            extractDanmakuFromDisplayArgs(arg);
                                        }
                                    }
                                }
                            }
                        });
                }
            }

            writeLog("显示类方法Hook完成");

        } catch (Throwable e) {
            writeLog("Hook显示方法失败: " + e.getMessage());
        }
    }

    /**
     * 从显示参数中提取弹幕
     */
    private static void extractDanmakuFromDisplayArgs(Object arg) {
        try {
            writeLog("尝试从显示参数中提取弹幕: " + arg.getClass().getName());

            // 检查是否是弹幕对象
            if (arg.getClass().getName().contains("Danmaku") || 
                arg.getClass().getName().contains("弹幕")) {

                writeLog("检测到弹幕显示参数");

                // 尝试提取弹幕信息
                DanmakuData danmaku = new DanmakuData();

                // 尝试获取昵称
                try {
                    Object nickname = XposedHelpers.getObjectField(arg, "nickname");
                    if (nickname != null) {
                        danmaku.setNickname(nickname.toString());
                        writeLog("从显示参数获取昵称: " + nickname.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                    writeLog("从显示参数获取昵称失败: " + e.getMessage());
                }

                // 尝试获取内容
                try {
                    Object content = XposedHelpers.getObjectField(arg, "content");
                    if (content != null) {
                        danmaku.setContent(content.toString());
                        writeLog("从显示参数获取内容: " + content.toString());
                    }
                } catch (Throwable e) {
                    // 字段可能不存在
                    writeLog("从显示参数获取内容失败: " + e.getMessage());
                }

                // 如果成功提取到数据，添加到列表
                if (danmaku.getNickname() != null && danmaku.getContent() != null) {
                    danmakuList.add(danmaku);
                    writeLog("从显示参数成功提取弹幕: " + danmaku.toString());

                    // 通知悬浮窗更新
                    notifyFloatingWindowUpdate();
                } else {
                    writeLog("从显示参数未能完整提取弹幕数据");
                }
            }

        } catch (Throwable e) {
            writeLog("从显示参数提取弹幕失败: " + e.getMessage());
        }
    }

    /**
     * 通知悬浮窗更新
     */
    private static void notifyFloatingWindowUpdate() {
        // 这里需要与悬浮窗服务通信
        // 可以通过广播、接口或静态变量等方式
        writeLog("通知悬浮窗更新，当前弹幕数量: " + danmakuList.size());

        // 简单实现：直接打印到日志
        for (DanmakuData danmaku : danmakuList) {
            writeLog("弹幕 - " + danmaku.getNickname() + ": " + danmaku.getContent());
        }
    }

    /**
     * 获取弹幕列表
     */
    public static List<DanmakuData> getDanmakuList() {
        return danmakuList;
    }

    /**
     * 清空弹幕列表
     */
    public static void clearDanmakuList() {
        danmakuList.clear();
        writeLog("弹幕列表已清空");
    }

    /**
     * 写入日志到文件
     */
    private static void writeLog(String message) {
        try {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            String logMessage = timestamp + " - " + TAG + ": " + message + "\n";

            File logFile = new File(LOG_FILE_PATH);
            FileOutputStream fos = new FileOutputStream(logFile, true);
            fos.write(logMessage.getBytes());
            fos.close();

            // 同时输出到Xposed日志
            XposedBridge.log(TAG + ": " + message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
