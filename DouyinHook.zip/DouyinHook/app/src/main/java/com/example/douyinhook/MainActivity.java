package com.example.douyinhook;

import android.Manifest;
import com.example.douyinhook.R;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;

public class MainActivity extends AppCompatActivity {
    
    private static final int PERMISSION_REQUEST_CODE = 1001;
    
    private TextView statusText;
    private TextView dataPathText;
    private Button openDataButton;
    private Button clearDataButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        checkPermissions();
        updateStatus();
    }
    
    private void initViews() {
        statusText = findViewById(R.id.status_text);
        dataPathText = findViewById(R.id.data_path_text);
        openDataButton = findViewById(R.id.open_data_button);
        clearDataButton = findViewById(R.id.clear_data_button);
        
        openDataButton.setOnClickListener(v -> openDataFolder());
        clearDataButton.setOnClickListener(v -> clearData());
    }
    
    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
        }
    }
    
    private void updateStatus() {
        File dataDir = new File(Environment.getExternalStorageDirectory(), "DouyinData");
        if (dataDir.exists()) {
            statusText.setText("模块状态: 已激活\n数据目录: " + dataDir.getAbsolutePath());
            dataPathText.setText("数据路径: " + dataDir.getAbsolutePath());
        } else {
            statusText.setText("模块状态: 已激活\n数据目录: 尚未创建");
            dataPathText.setText("数据路径: 尚未创建");
        }
    }
    
    private void openDataFolder() {
        File dataDir = new File(Environment.getExternalStorageDirectory(), "DouyinData");
        if (dataDir.exists()) {
            // 这里可以添加打开文件管理器的逻辑
            Toast.makeText(this, "数据目录: " + dataDir.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "数据目录尚未创建，请先使用抖音直播间", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void clearData() {
        File dataDir = new File(Environment.getExternalStorageDirectory(), "DouyinData");
        if (dataDir.exists()) {
            deleteRecursive(dataDir);
            Toast.makeText(this, "数据已清除", Toast.LENGTH_SHORT).show();
            updateStatus();
        } else {
            Toast.makeText(this, "没有数据需要清除", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            for (File child : fileOrDirectory.listFiles()) {
                deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "权限已授予", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要存储权限才能保存数据", Toast.LENGTH_SHORT).show();
            }
        }
    }
}