package com.example.application600.hooks;

import android.os.Bundle;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LiveRoomHook {
    
    private static final String TAG = "LiveRoomHook";
    
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        XposedBridge.log(TAG + ": 初始化直播间Hook");
        
        // Hook直播间Activity
        hookLiveRoomActivity(lpparam);
        
        // Hook直播间数据
        hookLiveRoomData(lpparam);
        
        // Hook直播间互动
        hookLiveRoomInteraction(lpparam);
    }
    
    private static void hookLiveRoomActivity(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试多种可能的直播间Activity类名
            String[] possibleClassNames = {
                "com.ss.android.ugc.aweme.live.LiveRoomActivity",
                "com.ss.android.ugc.aweme.live.LivePlayActivity",
                "com.ss.android.ugc.aweme.live.LiveActivity"
            };
            
            for (String className : possibleClassNames) {
                try {
                    Class<?> liveRoomClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    
                    // Hook onCreate方法
                    XposedHelpers.findAndHookMethod(liveRoomClass, "onCreate", 
                        Bundle.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log(TAG + ": 直播间已打开");
                                
                                // 获取直播间信息
                                Object activity = param.thisObject;
                                String roomId = getLiveRoomId(activity);
                                String anchorName = getAnchorName(activity);
                                
                                // 记录直播间信息
                                utils.DataUtils.logLiveRoomEntry(roomId, anchorName);
                            }
                        });
                    
                    // Hook onDestroy方法
                    XposedHelpers.findAndHookMethod(liveRoomClass, "onDestroy", 
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                XposedBridge.log(TAG + ": 直播间关闭");
                                utils.DataUtils.logLiveRoomExit();
                            }
                        });
                    
                    XposedBridge.log(TAG + ": 成功Hook直播间Activity: " + className);
                    break;
                    
                } catch (Throwable e) {
                    // 继续尝试下一个
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook直播间Activity失败: " + e.getMessage());
        }
    }
    
    private static String getLiveRoomId(Object activity) {
        try {
            // 尝试从Intent获取直播间ID
            android.content.Intent intent = ((android.app.Activity) activity).getIntent();
            if (intent != null) {
                return intent.getStringExtra("room_id");
            }
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 获取直播间ID失败: " + e.getMessage());
        }
        return "unknown";
    }
    
    private static String getAnchorName(Object activity) {
        try {
            // 尝试从Intent获取主播名称
            android.content.Intent intent = ((android.app.Activity) activity).getIntent();
            if (intent != null) {
                return intent.getStringExtra("anchor_name");
            }
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": 获取主播名称失败: " + e.getMessage());
        }
        return "unknown";
    }
    
    private static void hookLiveRoomData(XC_LoadPackage.LoadPackageParam lpparam) {
        // Hook直播间数据统计
        // 这里可以根据实际抖音版本进行调整
    }
    
    private static void hookLiveRoomInteraction(XC_LoadPackage.LoadPackageParam lpparam) {
        // Hook直播间互动（点赞、评论、礼物等）
        // 这里可以根据实际抖音版本进行调整
    }
}