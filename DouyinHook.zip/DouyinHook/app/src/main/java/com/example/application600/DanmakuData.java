package com.example.application600;

/**
 * 弹幕数据类
 */
public class DanmakuData {
    private String userId;
    private String nickname;
    private String content;
    private long timestamp;
    private String roomId;
    private int level;
    private String badge;
    
    public DanmakuData() {
        this.timestamp = System.currentTimeMillis();
    }
    
    public DanmakuData(String nickname, String content) {
        this.nickname = nickname;
        this.content = content;
        this.timestamp = System.currentTimeMillis();
    }
    
    // Getters and Setters
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getNickname() {
        return nickname;
    }
    
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }
    
    public int getLevel() {
        return level;
    }
    
    public void setLevel(int level) {
        this.level = level;
    }
    
    public String getBadge() {
        return badge;
    }
    
    public void setBadge(String badge) {
        this.badge = badge;
    }
    
    @Override
    public String toString() {
        return "DanmakuData{" +
                "nickname='" + nickname + '\'' +
                ", content='" + content + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}