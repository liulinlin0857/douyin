package com.example.douyinhook.hooks;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class UserInfoHook {
    
    private static final String TAG = "UserInfoHook";
    
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        XposedBridge.log(TAG + ": 初始化用户信息Hook");
        
        // Hook用户信息获取
        hookUserInfo(lpparam);
        
        // Hook用户等级信息
        hookUserLevel(lpparam);
        
        // Hook用户关注信息
        hookUserFollow(lpparam);
    }
    
    private static void hookUserInfo(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook用户信息类
            String[] possibleClassNames = {
                "com.ss.android.ugc.aweme.user.User",
                "com.ss.android.ugc.aweme.user.UserInfo",
                "com.ss.android.ugc.aweme.profile.model.User"
            };
            
            for (String className : possibleClassNames) {
                try {
                    Class<?> userClass = XposedHelpers.findClass(className, lpparam.classLoader);
                    
                    // Hook用户信息获取方法
                    XposedHelpers.findAndHookMethod(userClass, "getNickName", 
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                String nickname = (String) param.getResult();
                                XposedBridge.log(TAG + ": 获取用户昵称: " + nickname);
                                
                                // 可以在这里记录用户信息
                            }
                        });
                    
                    XposedBridge.log(TAG + ": 成功Hook用户信息类: " + className);
                    break;
                    
                } catch (Throwable e) {
                    // 继续尝试下一个
                }
            }
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook用户信息失败: " + e.getMessage());
        }
    }
    
    private static void hookUserLevel(XC_LoadPackage.LoadPackageParam lpparam) {
        // Hook用户等级信息
        // 这里可以根据实际抖音版本进行调整
    }
    
    private static void hookUserFollow(XC_LoadPackage.LoadPackageParam lpparam) {
        // Hook用户关注信息
        // 这里可以根据实际抖音版本进行调整
    }
}