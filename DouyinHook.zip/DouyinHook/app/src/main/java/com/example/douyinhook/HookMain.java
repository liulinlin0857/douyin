package com.example.douyinhook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookMain implements IXposedHookLoadPackage {
    
    private static final String TAG = "DouyinHook";
    private static final String LOG_FILE_PATH = "/sdcard/DouyinHook_logs.txt";
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // 只处理抖音应用
        if (!lpparam.packageName.equals("com.ss.android.ugc.aweme")) {
            return;
        }
        
        writeLog("抖音应用已加载，开始初始化Hook...");
        
        try {
            // 初始化Hook
            initHooks(lpparam);
            writeLog("所有Hook初始化完成");
            
        } catch (Throwable e) {
            writeLog("Hook初始化失败: " + e.getMessage());
        }
    }
    
    private void initHooks(XC_LoadPackage.LoadPackageParam lpparam) {
        // 1. Hook弹幕抓取
        DanmakuHook.init(lpparam);
        
        // 2. Hook礼物抓取
        GiftHook.init(lpparam);
        
        // 3. Hook Activity启动，启动悬浮窗服务
        hookActivityLaunch(lpparam);
    }
    
    private void hookActivityLaunch(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            writeLog("开始Hook Activity启动");
            
            // Hook Activity onCreate方法
            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", 
                Bundle.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Activity activity = (Activity) param.thisObject;
                        String activityName = activity.getClass().getName();
                        
                        writeLog("Activity onCreate: " + activityName);
                        
                        // 只在主Activity启动悬浮窗服务
                        if (activityName.contains("MainActivity") || 
                            activityName.contains("SplashActivity") ||
                            activityName.contains("HomeActivity")) {
                            
                            writeLog("在主Activity启动悬浮窗服务");
                            
                            // 启动悬浮窗服务
                            Intent serviceIntent = new Intent(activity, FloatingWindowService.class);
                            activity.startService(serviceIntent);
                            
                            writeLog("悬浮窗服务已启动");
                        }
                    }
                });
                
            writeLog("Activity Hook已设置完成");
            
        } catch (Throwable e) {
            writeLog("Hook Activity失败: " + e.getMessage());
        }
    }
    
    /**
     * 写入日志到文件
     */
    private void writeLog(String message) {
        try {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            String logMessage = timestamp + " - " + TAG + ": " + message + "\n";
            
            File logFile = new File(LOG_FILE_PATH);
            FileOutputStream fos = new FileOutputStream(logFile, true);
            fos.write(logMessage.getBytes());
            fos.close();
            
            // 同时输出到Xposed日志
            XposedBridge.log(TAG + ": " + message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}