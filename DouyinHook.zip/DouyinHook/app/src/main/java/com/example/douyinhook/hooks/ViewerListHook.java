package com.example.douyinhook.hooks;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import com.example.douyinhook.utils.DataUtils;

public class ViewerListHook {
    
    private static final String TAG = "ViewerListHook";
    
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        XposedBridge.log(TAG + ": 初始化观众列表Hook");
        
        // Hook观众列表视图
        hookViewerListView(lpparam);
        
        // Hook观众数据适配器
        hookViewerAdapter(lpparam);
        
        // Hook观众数据加载
        hookViewerDataLoader(lpparam);
    }
    
    private static void hookViewerListView(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 查找观众列表相关类
            Class<?> viewerListClass = findViewerListClass(lpparam);
            if (viewerListClass == null) {
                XposedBridge.log(TAG + ": 未找到观众列表类");
                return;
            }
            
            // Hook onLayout方法，在布局完成后获取数据
            XposedHelpers.findAndHookMethod(viewerListClass, "onLayout", 
                boolean.class, int.class, int.class, int.class, int.class, 
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        ViewGroup viewGroup = (ViewGroup) param.thisObject;
                        extractViewerDataFromView(viewGroup);
                    }
                });
                
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook观众列表视图失败: " + e.getMessage());
        }
    }
    
    private static Class<?> findViewerListClass(XC_LoadPackage.LoadPackageParam lpparam) {
        // 尝试多种可能的类名
        String[] possibleClassNames = {
            "com.ss.android.ugc.aweme.live.widget.ViewerListWidget",
            "com.ss.android.ugc.aweme.live.widget.ViewerListView",
            "com.ss.android.ugc.aweme.live.widget.ViewerRecyclerView",
            "com.ss.android.ugc.aweme.live.widget.ViewerListContainer"
        };
        
        for (String className : possibleClassNames) {
            try {
                return XposedHelpers.findClass(className, lpparam.classLoader);
            } catch (Throwable e) {
                // 继续尝试下一个
            }
        }
        
        return null;
    }
    
    private static void extractViewerDataFromView(ViewGroup viewGroup) {
        List<ViewerInfo> viewers = new ArrayList<>();
        
        // 遍历所有子视图
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            
            if (child instanceof ViewGroup) {
                // 递归提取
                viewers.addAll(extractFromViewGroup((ViewGroup) child));
            }
        }
        
        if (!viewers.isEmpty()) {
            XposedBridge.log(TAG + ": 从视图提取到 " + viewers.size() + " 个观众");
            DataUtils.saveViewerData(viewers);
        }
    }
    
    private static List<ViewerInfo> extractFromViewGroup(ViewGroup viewGroup) {
        List<ViewerInfo> viewers = new ArrayList<>();
        
        // 查找TextView作为用户名
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            
            if (child instanceof TextView) {
                TextView textView = (TextView) child;
                String text = textView.getText().toString().trim();
                
                // 判断是否为用户昵称（排除其他文本）
                if (isUserNickname(text)) {
                    ViewerInfo viewer = new ViewerInfo();
                    viewer.nickname = text;
                    viewer.timestamp = System.currentTimeMillis();
                    viewers.add(viewer);
                }
            }
        }
        
        return viewers;
    }
    
    private static boolean isUserNickname(String text) {
        // 简单的用户昵称判断逻辑
        // 可以根据实际情况调整
        return text.length() > 0 && 
               text.length() < 20 && 
               !text.contains("直播") && 
               !text.contains("点赞") &&
               !text.contains("关注");
    }
    
    private static void hookViewerAdapter(XC_LoadPackage.LoadPackageParam lpparam) {
        // Hook观众列表适配器
        // 这里可以根据实际抖音版本进行调整
    }
    
    private static void hookViewerDataLoader(XC_LoadPackage.LoadPackageParam lpparam) {
        // Hook观众数据加载器
        // 这里可以根据实际抖音版本进行调整
    }
    
    // 观众信息类
    public static class ViewerInfo {
        public String nickname;
        public String userId;
        public int level;
        public long timestamp;
        public String liveRoomId;
    }
}