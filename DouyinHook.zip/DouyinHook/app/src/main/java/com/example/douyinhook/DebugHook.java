package com.example.douyinhook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class DebugHook implements IXposedHookLoadPackage {
    
    private static final String TAG = "DouyinDebug";
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // 只处理抖音应用
        if (!lpparam.packageName.equals("com.ss.android.ugc.aweme")) {
            return;
        }
        
        XposedBridge.log(TAG + ": 模块已成功加载到抖音应用！");
        XposedBridge.log(TAG + ": 包名: " + lpparam.packageName);
        XposedBridge.log(TAG + ": 进程名: " + lpparam.processName);
        XposedBridge.log(TAG + ": ClassLoader: " + lpparam.getClass().getName());
        
        // Hook一个简单的Activity来测试
        hookMainActivity(lpparam);
        
        // Hook一个简单的系统方法来测试
        hookSystemMethod(lpparam);
    }
    
    private void hookMainActivity(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // 尝试Hook主Activity
            Class<?> mainActivityClass = XposedHelpers.findClass(
                "com.ss.android.ugc.aweme.splash.SplashActivity", 
                lpparam.classLoader
            );
            
            XposedHelpers.findAndHookMethod(mainActivityClass, "onCreate", 
                android.os.Bundle.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        XposedBridge.log(TAG + ": SplashActivity onCreate 已执行！");
                        XposedBridge.log(TAG + ": Activity: " + param.thisObject.getClass().getName());
                    }
                });
                
            XposedBridge.log(TAG + ": 成功Hook SplashActivity");
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook SplashActivity 失败: " + e.getMessage());
            
            // 尝试其他Activity
            try {
                Class<?> mainActivityClass = XposedHelpers.findClass(
                    "com.ss.android.ugc.aweme.MainActivity", 
                    lpparam.classLoader
                );
                
                XposedHelpers.findAndHookMethod(mainActivityClass, "onCreate", 
                    android.os.Bundle.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log(TAG + ": MainActivity onCreate 已执行！");
                        }
                    });
                    
                XposedBridge.log(TAG + ": 成功Hook MainActivity");
                
            } catch (Throwable e2) {
                XposedBridge.log(TAG + ": Hook MainActivity 也失败: " + e2.getMessage());
            }
        }
    }
    
    private void hookSystemMethod(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Hook一个简单的系统方法来测试模块是否工作
            XposedHelpers.findAndHookMethod("android.app.Application", lpparam.classLoader, 
                "onCreate", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        XposedBridge.log(TAG + ": Application.onCreate 已执行！");
                        XposedBridge.log(TAG + ": 模块正在工作！");
                    }
                });
                
            XposedBridge.log(TAG + ": 成功Hook Application.onCreate");
            
        } catch (Throwable e) {
            XposedBridge.log(TAG + ": Hook Application.onCreate 失败: " + e.getMessage());
        }
    }
}