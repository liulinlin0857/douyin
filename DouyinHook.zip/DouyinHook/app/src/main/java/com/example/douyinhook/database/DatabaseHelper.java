package com.example.douyinhook.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    
    private static final String DATABASE_NAME = "douyin_data.db";
    private static final int DATABASE_VERSION = 1;
    
    // 观众表
    private static final String TABLE_VIEWERS = "viewers";
    private static final String COL_ID = "id";
    private static final String COL_NICKNAME = "nickname";
    private static final String COL_USER_ID = "user_id";
    private static final String COL_LEVEL = "level";
    private static final String COL_TIMESTAMP = "timestamp";
    private static final String COL_LIVE_ROOM = "live_room";
    
    // 直播间表
    private static final String TABLE_LIVE_ROOMS = "live_rooms";
    private static final String COL_ROOM_ID = "room_id";
    private static final String COL_ANCHOR_NAME = "anchor_name";
    private static final String COL_START_TIME = "start_time";
    private static final String COL_END_TIME = "end_time";
    
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        // 创建观众表
        String createViewersTable = "CREATE TABLE " + TABLE_VIEWERS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NICKNAME + " TEXT, " +
                COL_USER_ID + " TEXT, " +
                COL_LEVEL + " INTEGER, " +
                COL_TIMESTAMP + " INTEGER, " +
                COL_LIVE_ROOM + " TEXT)";
        db.execSQL(createViewersTable);
        
        // 创建直播间表
        String createLiveRoomsTable = "CREATE TABLE " + TABLE_LIVE_ROOMS + " (" +
                COL_ROOM_ID + " TEXT PRIMARY KEY, " +
                COL_ANCHOR_NAME + " TEXT, " +
                COL_START_TIME + " INTEGER, " +
                COL_END_TIME + " INTEGER)";
        db.execSQL(createLiveRoomsTable);
        
        // 创建索引
        db.execSQL("CREATE INDEX idx_viewers_timestamp ON " + TABLE_VIEWERS + "(" + COL_TIMESTAMP + ")");
        db.execSQL("CREATE INDEX idx_viewers_live_room ON " + TABLE_VIEWERS + "(" + COL_LIVE_ROOM + ")");
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 升级数据库
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VIEWERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LIVE_ROOMS);
        onCreate(db);
    }
    
    // 插入观众数据
    public long insertViewer(String nickname, String userId, int level, long timestamp, String liveRoomId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NICKNAME, nickname);
        values.put(COL_USER_ID, userId);
        values.put(COL_LEVEL, level);
        values.put(COL_TIMESTAMP, timestamp);
        values.put(COL_LIVE_ROOM, liveRoomId);
        
        long id = db.insert(TABLE_VIEWERS, null, values);
        db.close();
        return id;
    }
    
    // 获取所有观众
    public List<ViewerData> getAllViewers() {
        List<ViewerData> viewers = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_VIEWERS, null, null, null, null, null, COL_TIMESTAMP + " DESC");
        
        if (cursor.moveToFirst()) {
            do {
                ViewerData viewer = new ViewerData();
                viewer.id = cursor.getInt(cursor.getColumnIndex(COL_ID));
                viewer.nickname = cursor.getString(cursor.getColumnIndex(COL_NICKNAME));
                viewer.userId = cursor.getString(cursor.getColumnIndex(COL_USER_ID));
                viewer.level = cursor.getInt(cursor.getColumnIndex(COL_LEVEL));
                viewer.timestamp = cursor.getLong(cursor.getColumnIndex(COL_TIMESTAMP));
                viewer.liveRoomId = cursor.getString(cursor.getColumnIndex(COL_LIVE_ROOM));
                viewers.add(viewer);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return viewers;
    }
    
    // 观众数据类
    public static class ViewerData {
        public int id;
        public String nickname;
        public String userId;
        public int level;
        public long timestamp;
        public String liveRoomId;
    }
}