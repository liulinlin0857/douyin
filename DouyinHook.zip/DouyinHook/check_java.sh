#!/bin/bash
echo "检查Java环境..."
if command -v java &> /dev/null; then
    echo "Java已安装:"
    java -version
else
    echo "Java未安装"
    echo "尝试在Termux中安装Java..."
    if command -v pkg &> /dev/null; then
        echo "检测到Termux包管理器"
        echo "运行: pkg install openjdk-17"
    else
        echo "未找到包管理器"
    fi
fi