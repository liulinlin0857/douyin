# 抖音观众数据采集模块 - 安装指南

## 快速安装（推荐）

### 方法一：直接编译安装
1. **下载项目**
   - 项目已保存在 `/sdcard/Download/DouyinHook/`

2. **安装Android Studio**
   - 从官网下载：https://developer.android.com/studio
   - 安装并配置Android SDK

3. **导入项目**
   - 打开Android Studio
   - 选择 "Open an existing Android Studio project"
   - 选择 `/sdcard/Download/DouyinHook/` 目录

4. **编译APK**
   - 等待Gradle同步完成
   - 点击菜单：Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   - 编译完成后，APK位于：`app/build/outputs/apk/debug/app-debug.apk`

5. **安装APK**
   - 将APK传输到手机
   - 安装APK（需要开启"未知来源"）

6. **激活模块**
   - 打开LSPosed管理器
   - 进入"模块"页面
   - 找到"抖音观众数据采集"模块
   - 开启模块开关
   - 点击模块进入设置
   - 选择"作用域"
   - 勾选"抖音"（com.ss.android.ugc.aweme）

7. **重启应用**
   - 强制停止抖音应用
   - 重新打开抖音

### 方法二：使用命令行编译（高级用户）

```bash
# 1. 确保已安装Android SDK和Java JDK
# 2. 进入项目目录
cd /sdcard/Download/DouyinHook

# 3. 赋予gradlew执行权限（如果存在）
chmod +x gradlew

# 4. 编译debug APK
./gradlew assembleDebug

# 5. APK位置
ls -la app/build/outputs/apk/debug/
```

## 模块配置

### 1. LSPosed配置
- **作用域**：必须选择抖音（com.ss.android.ugc.aweme）
- **模式**：推荐使用"全局模式"或"兼容模式"
- **版本**：建议使用LSPosed 1.8.6+

### 2. 权限配置
- **存储权限**：模块需要存储权限保存数据
- **后台权限**：允许模块后台运行

## 使用说明

### 1. 启动模块
1. 确保LSPosed管理器中模块已激活
2. 重启抖音应用
3. 进入任意直播间

### 2. 数据采集
模块会自动采集以下数据：
- 观众列表（实时更新）
- 直播间信息
- 用户昵称
- 时间戳

### 3. 数据查看
数据保存在：
```
/sdcard/DouyinData/
├── app_launch.log          # 应用启动日志
├── live_room.log           # 直播间日志
├── viewers.log             # 观众日志
├── viewers_YYYYMMDD_HHMMSS.json  # JSON格式数据
└── ...                     # 其他文件
```

## 故障排除

### 问题1：模块不工作
**解决方案**：
1. 检查LSPosed管理器中模块是否激活
2. 确认作用域已选择抖音
3. 重启抖音应用
4. 检查设备是否有存储权限

### 问题2：数据未保存
**解决方案**：
1. 检查 `/sdcard/DouyinData/` 目录是否存在
2. 确保有写入存储的权限
3. 检查存储空间是否充足

### 问题3：抖音版本不兼容
**解决方案**：
1. 模块针对抖音最新版本设计
2. 如遇兼容性问题，可尝试更新抖音版本
3. 或修改Hook类名适配旧版本

## 注意事项

1. **法律合规**：仅用于学习研究，不得用于商业用途
2. **隐私保护**：采集的数据请妥善保管，不得泄露他人隐私
3. **版本更新**：抖音更新可能需要重新适配模块
4. **系统要求**：需要Android 9.0+和root权限

## 技术支持

如遇问题，请提供：
1. 设备型号和系统版本
2. 抖音版本号
3. LSPosed版本
4. 错误日志

## 版本信息
- 模块版本：1.0
- 支持抖音版本：最新版
- 最低Android版本：9.0 (API 28)
- 目标Android版本：14 (API 34)