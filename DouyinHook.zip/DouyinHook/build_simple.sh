#!/bin/bash

# 简化版编译脚本 - 用于在手机上编译

echo "=== 抖音观众数据采集模块 - 简化编译脚本 ==="
echo ""

# 检查是否在正确的目录
if [ ! -f "build.gradle" ]; then
    echo "错误: 请在DouyinHook项目根目录运行此脚本"
    exit 1
fi

# 检查Java
if ! command -v java &> /dev/null; then
    echo "警告: 未找到Java，尝试安装..."
    
    # 检查是否在Termux中
    if command -v pkg &> /dev/null; then
        echo "检测到Termux环境，正在安装Java..."
        pkg update -y
        pkg install -y openjdk-17
    else
        echo "错误: 未找到Java，请手动安装"
        echo "在Termux中运行: pkg install openjdk-17"
        exit 1
    fi
fi

echo "Java版本:"
java -version

# 检查是否可以下载Gradle
echo ""
echo "检查Gradle..."
if [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo "下载Gradle wrapper..."
    
    # 创建wrapper目录
    mkdir -p gradle/wrapper
    
    # 下载gradle-wrapper.jar
    if command -v wget &> /dev/null; then
        wget -q "https://raw.githubusercontent.com/gradle/gradle/v8.2.0/gradle/wrapper/gradle-wrapper.jar" -O gradle/wrapper/gradle-wrapper.jar
    elif command -v curl &> /dev/null; then
        curl -sL "https://raw.githubusercontent.com/gradle/gradle/v8.2.0/gradle/wrapper/gradle-wrapper.jar" -o gradle/wrapper/gradle-wrapper.jar
    else
        echo "错误: 未找到wget或curl"
        exit 1
    fi
fi

# 检查gradlew是否可执行
if [ ! -f "gradlew" ]; then
    echo "错误: 未找到gradlew脚本"
    exit 1
fi

echo ""
echo "开始编译..."
echo "这可能需要一些时间，请耐心等待..."
echo ""

# 运行Gradle编译
./gradlew assembleDebug

# 检查编译结果
if [ $? -eq 0 ]; then
    echo ""
    echo "=== 编译成功! ==="
    echo ""
    
    # 查找APK文件
    APK_FILE=$(find . -name "*.apk" -type f | head -1)
    
    if [ -n "$APK_FILE" ]; then
        echo "APK文件: $APK_FILE"
        echo "文件大小: $(ls -lh "$APK_FILE" | awk '{print $5}')"
        echo ""
        echo "下一步:"
        echo "1. 将APK文件传输到手机"
        echo "2. 安装APK"
        echo "3. 在LSPosed管理器中激活模块"
        echo "4. 选择抖音应用作为作用域"
        echo "5. 重启抖音应用"
        echo "6. 进入直播间自动采集数据"
    else
        echo "警告: 未找到APK文件"
        echo "请检查编译日志"
    fi
else
    echo ""
    echo "=== 编译失败! ==="
    echo "请检查错误信息并修复"
    echo ""
    echo "常见问题:"
    echo "1. Java版本不兼容 - 尝试安装JDK 17"
    echo "2. 网络问题 - 检查网络连接"
    echo "3. 依赖下载失败 - 尝试使用VPN"
    echo "4. 存储空间不足 - 清理存储空间"
fi